<?php
// Remplissez ces informations et renommez ce fichier en 'config.php'
return [
    'ling_url' => "https://www.playground.dyskute.com/dist/message",
    'bearer' => "VOTRE_BEARER_TOKEN",
    'app_token' => "VOTRE_APP_TOKEN"
];